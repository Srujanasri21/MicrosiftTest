﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmployeeManager
{
    public class Employees
    {
        List<Employee> empList = new List<Employee>();

        public Employees(string strPath)
        {

            if (!string.IsNullOrEmpty(strPath))
            {
                if (File.Exists(strPath))
                {
                    string[] lines = File.ReadAllLines(strPath);
                    foreach (string line in lines)
                    {
                        Employee emp = new Employee();
                        int sal = 0;
                        string[] col = line.Split(',');
                        int.TryParse(col[2], out sal);
                        if (sal != 0)
                        {
                            if (empList.Count > 0)
                            {
                                if (empList.FindAll(e => e.employeeId == col[0]).Count < 1)
                                {
                                    if (!string.IsNullOrEmpty(col[1]))
                                    {
                                        if (!DuplicateManagerCheck(col[0]) && !IsCircularReferenceCheck(col[0], col[1]))
                                            empList.Add(new Employee { employeeId = col[0].Trim(), managerId = col[1].Trim(), salary = sal });
                                    }
                                    else
                                    {
                                        if (!empList.Exists(e => string.IsNullOrEmpty(e.managerId)))
                                        {
                                            empList.Add(new Employee { employeeId = col[0].Trim(), salary = sal });
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Can not add duplicate details of employee " + col[0] + " !");
                                }
                            }
                            else
                            {
                                empList.Add(new Employee { employeeId = col[0].Trim(), managerId = col[1].Trim(), salary = sal });
                            }
                        }
                        else
                        {
                            Console.WriteLine("Salary should be an integer value !");
                        }
                    }
                    ValidateManagerNotEmp();
                }
                else
                {
                    Console.WriteLine("File " + strPath + " does not exist!");
                }
            }
            else
            {
                Console.WriteLine("Please enter the csv file path!");
            }
        }
        /// <summary>
        /// Function/Method to check for the Circular Reference in Reporting Manager
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="managerId"></param>
        /// <returns></returns>
        bool IsCircularReferenceCheck(string employeeId, string managerId)
        {
            bool isCircularRef = false;
            string empId = string.Empty;
            foreach (Employee emp in empList)
            {
                if (emp.managerId == employeeId)
                {
                    empId = emp.employeeId;
                    break;
                }
            }
            foreach (Employee emp in empList)
            {
                if (emp.managerId == empId)
                {
                    if (emp.employeeId == managerId)
                    {
                        isCircularRef = true;
                        Console.WriteLine("Circular Reference occurred so skipping this record...");
                    }
                }
            }
            if (isCircularRef)
                empList.RemoveAll(e => e.employeeId == empId);
            return isCircularRef;
        }

        /// <summary>
        /// Function/Method to check whether employee is having multiple managers
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        bool DuplicateManagerCheck(string employeeId)
        {
            bool isDuplicateLink = false;
            string managerId = string.Empty;
            foreach (Employee emp in empList)
            {
                if (emp.employeeId == employeeId)
                {
                    if (string.IsNullOrEmpty(managerId))
                    {
                        managerId = emp.managerId;
                    }
                    else
                    {
                        if (managerId != emp.managerId)
                        {
                            isDuplicateLink = true;
                            Console.WriteLine("Employee with multiple managers is not allowed");
                            break;
                        }
                    }
                }
            }
            return isDuplicateLink;
        }
        /// <summary>
        /// For displaying Employee details read from the csv
        /// </summary>
        /// <returns></returns>
        public List<Employee> ShowEmployees()
        {
            return empList;
        }
        /// <summary>
        /// Function/Method for salary budget
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public int SalaryBudget(string employeeId)
        {
            int sal = 0;
            foreach (Employee emp in empList)
            {
                if (emp.employeeId == employeeId)
                {
                    sal += emp.salary;
                    sal += GetManager(emp.employeeId);
                }
            }
            return sal;
        }

        /// <summary>
        /// Recursive function/method for salary calculation
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        int GetManager(string employeeId)
        {
            int sal = 0;
            foreach (Employee emp in empList)
            {
                if (emp.managerId == employeeId)
                {
                    sal += emp.salary;
                    sal += GetManager(emp.employeeId);
                }
            }
            return sal;
        }
        /// <summary>
        /// Function/Method to remove Employees having Managers [who themselves are not employees]
        /// </summary>
        void ValidateManagerNotEmp()
        {
            string managerIds = "";

            foreach (Employee emp in empList)
            {
                bool found = false;
                foreach (Employee emp1 in empList)
                {
                    if (emp1.employeeId == emp.managerId)
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    managerIds += emp.managerId + ",";
                }
            }
            string[] separator = { "," };
            string[] managers = managerIds.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            foreach (string manager in managers)
            {
                empList.RemoveAll(e => manager == e.managerId);
            }
        }
    }

    /// <summary>
    /// Employee Class
    /// </summary>
    public class Employee
    {
        public string employeeId { get; set; }
        public string managerId { get; set; }
        public int salary { get; set; }
    }
}
