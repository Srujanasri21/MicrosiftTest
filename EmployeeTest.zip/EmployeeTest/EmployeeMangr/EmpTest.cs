﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeManager;
using System.IO;

namespace EmployeeManagerUnitTest
{
    [TestClass]
    public class EmpTest
    {
        static string solution_dir = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
        string parentDir = Directory.GetParent(solution_dir).Parent.FullName.Replace("bin\\Debug", string.Empty);
        [TestMethod]
        public void CheckSalaryBudget()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpB.csv");
            Assert.AreEqual(1800, objEmployees.SalaryBudget("Employee2"));
            Assert.AreEqual(500, objEmployees.SalaryBudget("Employee3"));
            Assert.AreEqual(3800, objEmployees.SalaryBudget("Employee1"));
        }

        [TestMethod]
        public void CheckSalary()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpS.csv");
            Assert.AreEqual(1800, objEmployees.SalaryBudget("Employee2"));
        }

        [TestMethod]
        public void CheckMultipleManager()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpDoub.csv");
            Assert.AreEqual(500, objEmployees.SalaryBudget("Employee4"));
            Assert.AreEqual(500, objEmployees.SalaryBudget("Employee3"));
        }

        [TestMethod]
        public void CheckOnlyOneCEO()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpC.csv");
            Assert.AreEqual(3800, objEmployees.SalaryBudget("Employee1"));
            Assert.AreEqual(0, objEmployees.SalaryBudget("Employee7"));
        }

        [TestMethod]
        public void CheckCircularReference()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpCir.csv");
            Assert.AreEqual(0, objEmployees.SalaryBudget("Employee2"));
            Assert.AreEqual(0, objEmployees.SalaryBudget("Employee3"));
            Assert.AreEqual(0, objEmployees.SalaryBudget("Employee4"));
        }

        [TestMethod]
        public void CheckManagerWhoIsNotEmployee()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmpCir.csv");
            Assert.AreEqual(1500, objEmployees.SalaryBudget("Employee1"));
            Assert.AreEqual(500, objEmployees.SalaryBudget("Employee5"));
            Assert.AreEqual(0, objEmployees.SalaryBudget("Employee4"));
        }
    }
}
